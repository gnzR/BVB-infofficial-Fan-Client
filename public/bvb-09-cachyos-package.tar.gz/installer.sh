#!/usr/bin/env bash
set -e

YELLOW='\033[1;33m'
GREEN='\033[1;32m'
BLUE='\033[1;34m'
NC='\033[0m'

clear
echo -e "${YELLOW}
  ____  _   _ ____     ___   ___  
 | __ )| | | | __ )   / _ \ / _ \ 
 |  _ \| | | |  _ \  | | | | (_) |
 | |_) | |_| | |_) | | |_| |\__, |
 |____/ \___/|____/   \___/   /_/ 
${NC}"
echo -e "${YELLOW}[+] Starte BVB Inofficial Fan Client Beta 1.909.3 Installation auf CachyOS...${NC}\n"

echo -e "${BLUE}[1/4] Prüfe CachyOS / Arch System-Abhängigkeiten (Qt6 & Multimedia)...${NC}"
DEPS=("python-pyqt6-webengine" "python-pyqt6" "libnotify" "pipewire" "pipewire-pulse" "alsa-utils" "gst-plugins-good" "gst-plugin-pipewire")
MISSING=()

for dep in "${DEPS[@]}"; do
    if ! pacman -Qs "^$dep$" > /dev/null 2>&1; then
        MISSING+=("$dep")
    fi
done

if [ ${#MISSING[@]} -ne 0 ]; then
    echo -e "  ${YELLOW}[!] Installiere fehlende Pakete: ${MISSING[*]}${NC}"
    if command -v paru &> /dev/null; then
        paru -S --noconfirm --needed "${MISSING[@]}"
    elif command -v yay &> /dev/null; then
        yay -S --noconfirm --needed "${MISSING[@]}"
    else
        sudo pacman -S --noconfirm --needed "${MISSING[@]}"
    fi
fi

echo -e "${BLUE}[2/4] Installiere Anwendungsdateien (Offline-Desktop-Bundle Beta 1.909.3)...${NC}"
APP_DIR="$HOME/.local/share/bvb-desktop"
mkdir -p "$APP_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$SCRIPT_DIR/app" ]; then
    rm -rf "$APP_DIR/app"
    cp -r "$SCRIPT_DIR/app" "$APP_DIR/"
fi
[ -f "$SCRIPT_DIR/BVB09-App.html" ] && cp -f "$SCRIPT_DIR/BVB09-App.html" "$APP_DIR/BVB09-App.html"
[ -f "$SCRIPT_DIR/qt_runner.py" ] && cp -f "$SCRIPT_DIR/qt_runner.py" "$APP_DIR/qt_runner.py" && chmod +x "$APP_DIR/qt_runner.py"
[ -f "$SCRIPT_DIR/deinstall.sh" ] && cp -f "$SCRIPT_DIR/deinstall.sh" "$APP_DIR/deinstall.sh" && chmod +x "$APP_DIR/deinstall.sh"

echo -e "${BLUE}[3/4] Erstelle Absturz-Sicheren Starter (/usr/local/bin/bvb-desktop)...${NC}"
cat << 'EOF_LAUNCH' | sudo tee /usr/local/bin/bvb-desktop > /dev/null
#!/usr/bin/env bash
APP_DIR="$HOME/.local/share/bvb-desktop"
export QT_QPA_PLATFORM="wayland;xcb"
export QT_AUTO_SCREEN_SCALE_FACTOR=1
export QTWEBENGINE_CHROMIUM_FLAGS="--disable-gpu-sandbox --in-process-gpu --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-gpu-memory-buffer-video-frames --allow-file-access-from-files --disable-web-security"
export WEBKIT_DISABLE_DMABUF_RENDERER=1
export WEBKIT_DISABLE_COMPOSITING_MODE=1
trap 'kill $(jobs -p) 2>/dev/null; exit 0' SIGINT SIGTERM

# Engine 1: Nativer Qt6 WebEngine Runner
if command -v python3 &>/dev/null && [ -f "$APP_DIR/qt_runner.py" ]; then
    python3 "$APP_DIR/qt_runner.py" "$@"
    STATUS=$?
    if [ $STATUS -eq 0 ] || [ $STATUS -eq 130 ] || [ $STATUS -eq 2 ]; then
        exit 0
    fi
fi

# Engine 2: Cachy-Browser / Chromium / Brave / Edge im isolierten App-Fenster (Serverless BVB09-App.html)
TARGET_HTML="$APP_DIR/BVB09-App.html"
[ ! -f "$TARGET_HTML" ] && TARGET_HTML="$APP_DIR/app/index.html"

for b in cachy-browser chromium google-chrome-stable google-chrome brave-browser brave microsoft-edge-stable; do
    if command -v "$b" &>/dev/null; then
        exec "$b" --app="file://$TARGET_HTML?installed=true" --window-size=1420,920 --disable-dev-shm-usage --allow-file-access-from-files --disable-web-security --user-data-dir="$HOME/.local/share/bvb-desktop/browser-profile" "$@"
    fi
done

if command -v xdg-open &>/dev/null; then
    exec xdg-open "file://$TARGET_HTML"
fi
EOF_LAUNCH
sudo chmod +x /usr/local/bin/bvb-desktop

echo -e "${BLUE}[4/4] Richte Desktop-Icon & Anwendungsmenü ein...${NC}"
DESKTOP_ENTRY="[Desktop Entry]
Name=BVB 09 Transfermarkt Client
Comment=Borussia Dortmund 09 Desktop Client Beta 1.909.3 (Niko Kovac Edition)
Exec=/usr/local/bin/bvb-desktop
Icon=bvb-logo
Terminal=false
Type=Application
Categories=Sports;News;Network;"

mkdir -p "$HOME/.local/share/applications"
echo "$DESKTOP_ENTRY" > "$HOME/.local/share/applications/bvb-desktop.desktop"
chmod +x "$HOME/.local/share/applications/bvb-desktop.desktop"

if [ -d "$HOME/Desktop" ]; then
    echo "$DESKTOP_ENTRY" > "$HOME/Desktop/BVB-09-Desktop.desktop"
    chmod +x "$HOME/Desktop/BVB-09-Desktop.desktop"
fi

update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true

echo -e "\n${GREEN}[✓] BVB 09 Client Beta 1.909.3 ERFOLGREICH auf CachyOS installiert!${NC}"
echo -e "${YELLOW}[+] Starten: im Terminal mit 'bvb-desktop' oder über dein Anwendungsmenü.${NC}\n"
