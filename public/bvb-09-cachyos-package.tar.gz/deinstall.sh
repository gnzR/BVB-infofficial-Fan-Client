#!/usr/bin/env bash
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
NC='\033[0m'

echo -e "${YELLOW}[+] Deinstalliere BVB 09 Desktop Client von CachyOS...${NC}"
sudo rm -f /usr/local/bin/bvb-desktop
rm -f "$HOME/.local/share/applications/bvb-desktop.desktop"
rm -f "$HOME/Desktop/BVB-09-Desktop.desktop"
rm -rf "$HOME/.local/share/bvb-desktop"
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
echo -e "${GREEN}[✓] BVB 09 Client und alle Verknüpfungen wurden vollständig entfernt!${NC}"
