===================================================================
 BORUSSIA DORTMUND 09 DESKTOP CLIENT Beta 1.909.6 FOR CACHYOS / ARCH
===================================================================

NEU IN VERSION Beta 1.909.6:
  - Zweizeilige Profi-Desktop-Navigation (inkl. 30 Tage Statistik)
  - Geprüftes Netradio inkl. Radio Euskirchen (192 kbps MP3) & Radio 91.2 Dortmund
  - Idee 1: Interaktive BVB-Taktiktafel & Wunsch-Startelf-Planer (Niko Kovac)
  - Idee 2: UEFA Champions League 36er-Tabelle & K.o.-Runden-Rechner
  - Idee 4: Live-Stadionwetter Signal Iduna Park, Anpfiff-Countdown & .ics Export

INSTALLATION:
  chmod +x installer.sh deinstall.sh
  ./installer.sh

STARTEN:
  bvb-desktop (oder direkt BVB09-App.html öffnen)

DEINSTALLATION:
  ./deinstall.sh
===================================================================
