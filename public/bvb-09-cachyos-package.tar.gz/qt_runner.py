#!/usr/bin/env python3
import sys
import os
import signal

signal.signal(signal.SIGINT, signal.SIG_DFL)
os.environ.setdefault("QT_QPA_PLATFORM", "wayland;xcb")
os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = "--disable-gpu-sandbox --in-process-gpu --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-gpu-memory-buffer-video-frames --allow-file-access-from-files --disable-web-security"

app_dir = os.path.dirname(os.path.abspath(__file__))
serverless_html = os.path.join(app_dir, "BVB09-App.html")
if not os.path.exists(serverless_html):
    serverless_html = os.path.join(app_dir, "app", "index.html")

try:
    from PyQt6.QtCore import QUrl
    from PyQt6.QtGui import QDesktopServices, QColor
    from PyQt6.QtWidgets import QApplication, QMainWindow
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings, QWebEnginePage
except ImportError:
    try:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices, QColor
        from PySide6.QtWidgets import QApplication, QMainWindow
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebEngineCore import QWebEngineSettings, QWebEnginePage
    except ImportError:
        sys.exit(1)

app = QApplication(sys.argv)
app.setApplicationName("BVB Inofficial Fan Client")

window = QMainWindow()
window.setWindowTitle("BVB Inofficial Fan Client · Beta 1.909.2 (CachyOS Desktop App)")
window.resize(1440, 920)
window.setStyleSheet("background-color: #07080a;")

class ExternalWebEnginePage(QWebEnginePage):
    _held_pages = []
    def acceptNavigationRequest(self, url, navType, isMainFrame):
        url_str = url.toString()
        if url_str.startswith("file://") or url_str.startswith("data:") or url_str.startswith("blob:"):
            return super().acceptNavigationRequest(url, navType, isMainFrame)
        QDesktopServices.openUrl(url)
        return False
    def createWindow(self, windowType):
        temp_page = ExternalWebEnginePage(self.profile(), self)
        ExternalWebEnginePage._held_pages.append(temp_page)
        def on_url_changed(u):
            if u.isValid() and not u.isEmpty():
                QDesktopServices.openUrl(u)
                if temp_page in ExternalWebEnginePage._held_pages:
                    ExternalWebEnginePage._held_pages.remove(temp_page)
        temp_page.urlChanged.connect(on_url_changed)
        return temp_page

view = QWebEngineView()
page = ExternalWebEnginePage(view)
page.setBackgroundColor(QColor(7, 8, 10))
view.setPage(page)
view.setStyleSheet("background-color: #07080a;")

settings = view.settings()
settings.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
settings.setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
settings.setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)

view.load(QUrl.fromLocalFile(serverless_html))
window.setCentralWidget(view)
window.show()
sys.exit(app.exec())
